<?php

$lang['btn_vote']         = 'Abstimmen';
$lang['btn_change']       = 'Stimme &Auml;ndern';
$lang['count']            = 'Summe:';
$lang['final_result']     = 'Ergebnis:';
$lang['edit']             = '&auml;ndern';

// error messages
$lang['must_be_logged_in']     = 'Du must eingeloggt sein um abstimmen zu d&uuml;rfen!';
$lang['ip_has_already_voted']  = 'Diese IP (<code>%s</code>) hat bereits abgestimmt!';
$lang['you_voted_already']     = 'Du hast bereits abgestimmt!';
$lang['not_allowed_to_change'] = 'Du darfst diese Stimme nicht ver&auml;ndern!';
$lang['vote_saved']            = 'Deine Stimme wurde gez&auml;hlt.';
$lang['vote_deleted']          = 'Stimme gel&ouml;scht.';


?>
