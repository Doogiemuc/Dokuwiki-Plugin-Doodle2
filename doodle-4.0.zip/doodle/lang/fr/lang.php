<?php

// headers and buttons
$lang['btn_vote']         = 'Vote';
$lang['btn_change']       = 'Changer de vote';
$lang['count']            = 'Total&nbsp;:';
$lang['final_result']     = 'R&eacute;sultat final&nbsp;:';
$lang['edit']             = '&Eacute;diter&nbsp;';

// info messages
$lang['poll_closed']           = 'Ce doodle a &eacute;t&eacute; ferm&eacute;.';
$lang['vote_saved']            = 'Votre vote a &eacute;t&eacute; sauvegard&eacute;.';
$lang['vote_deleted']          = 'Votre vote a &eacute;t&eacute; supprim&eacute;.';

// error messages
$lang['dont_have_name']        = 'Vous avez oubli&eacute; de mettre votre nom !';
$lang['must_be_logged_in']     = 'Vous devez &ecirc;tre connect&eacute; pour voter !';
$lang['ip_has_already_voted']  = 'L\'IP (<code>%s</code>) a d&eacute;j&agrave; vot&eacute; !';
$lang['you_voted_already']     = 'Vous avez d&eacute;j&agrave; vot&eacute; !';
$lang['not_allowed_to_change'] = 'Vous n\'&ecirc;tes pas autoris&eacute; &agrave; changer ce vote !';
$lang['select_one_option']     = 'Choisir une option.';

?>
